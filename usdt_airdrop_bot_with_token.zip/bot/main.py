
import os
from telegram import Update, InlineKeyboardButton, InlineKeyboardMarkup
from telegram.ext import ApplicationBuilder, CommandHandler, CallbackContext
from dotenv import load_dotenv

load_dotenv()

BONUS = 0.1
MIN_WITHDRAW = 1.0
TOKEN = os.getenv("BOT_TOKEN")

users = {}

async def start(update: Update, context: CallbackContext):
    user_id = update.effective_user.id
    if user_id not in users:
        users[user_id] = {"balance": BONUS, "referrals": []}
        await update.message.reply_text(f"You received {BONUS} USDT as welcome bonus!")
    else:
        await update.message.reply_text("You already started the bot.")

app = ApplicationBuilder().token(TOKEN).build()
app.add_handler(CommandHandler("start", start))

if __name__ == "__main__":
    app.run_polling()
